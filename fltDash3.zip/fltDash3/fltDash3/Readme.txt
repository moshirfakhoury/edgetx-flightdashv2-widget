Overview

FlightDash is a lightweight all-in-one telemetry dashboard widget for EdgeTX radios such as the RadioMaster TX16S, designed to show the most important flight data at a glance using clear gauges, segmented bars, and color-coded indicators so you can instantly see signal health, power status, temperatures, and control inputs while flying.

Features
- Large RPM speedometer with needle and throttle %
- ESC temperature gauge (TESC)
- Segmented RSS signal strength bar (color coded)
- Segmented Link Quality (RQly) bar
- BEC temperature bar (TBEC)
- BEC voltage bar (VBEC)
- RX battery icon with total voltage per-cell voltage
- TX battery indicator
- Vertical timer progress bar
- Arm / Motor / Flight Mode status tiles
- Live stick values (Ail, Ele, Thr/Collective, Rud)
- RAM-only min/max tracking
- One global variable value can be displayed e.g. for Flight Counter
- Optimized for small screens and fast readability