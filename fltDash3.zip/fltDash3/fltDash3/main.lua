---------------------------------------------------------------------------
-- FlightDash V3 Widget 
-- EdgeTX 2.11+
-- RAM-only min/max
---------------------------------------------------------------------------

local name = "fltDash3"

---------------------------------------------------------------------------
-- OPTIONS
---------------------------------------------------------------------------

local options = {
  { "Arm",       SOURCE, 0 },
  { "Motor",     SOURCE, 0 },
  { "Rx Signal", SOURCE, 0 },
  { "Rx Qty",    SOURCE, 0 },
  { "Rpm",       SOURCE, 0 },
  { "GV",        SOURCE, 0 },
  { "Rx Batt",   SOURCE, 0 },
  { "Curr",      SOURCE, 0 },
  { "Tesc",      SOURCE, 0 },
  { "Rx Cells",  SOURCE, 0 },
}

---------------------------------------------------------------------------
-- MIN / MAX STATE (RAM ONLY)
---------------------------------------------------------------------------

local stats = {
  RPM  = { min = nil, max = nil },
  RSS  = { min = nil, max = nil },
  RQTY = { min = nil, max = nil },
}

---------------------------------------------------------------------------
-- CREATE / UPDATE
---------------------------------------------------------------------------

local function create(zone, opts)
  return { zone = zone, options = opts or {} }
end

local function update(widget, opts)
  widget.options = opts
end

local function sourceLabel(src, fallback)
  if src ~= 0 then
    local info = getSourceInfo(src)
    if info and info.name then
      return info.name
    end
  end
  return fallback
end

-- RX Battery Icon
local function drawBatteryIcon(x, y, w, h, percent, color)
  lcd.drawRectangle(x, y, w, h, WHITE)
  lcd.drawFilledRectangle(x + w, y + h / 3, 4, h / 3, WHITE)
  lcd.drawFilledRectangle(x + 1, y + 1, (w - 2) * percent, h - 2, color)
end

--Standard EdgeTx Colours
--BLACK
--WHITE
--GREEN
--DARKGREEN
--YELLOW
--RED
--DARKRED
--GREY
--DARKGREY
--BLUE
--ORANGE

---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------

local function refresh(widget)
  local z   = widget.zone
  local opt = widget.options

  lcd.drawFilledRectangle(z.x, z.y, z.w, z.h, COLOR_BLACK)

local PURPLE = lcd.RGB(149, 66, 245)
local BROWN = lcd.RGB(79, 54, 39)
local PINK = lcd.RGB(206, 126, 252)
local CYAN = lcd.RGB(58, 242, 242)
local LIGHTBLUE = lcd.RGB(25, 175, 255)


  -------------------------------------------------------------------------
  -- STATES
  -------------------------------------------------------------------------

  local armOn   = opt.Arm   ~= 0 and getValue(opt.Arm)   > 0
  local motorOn = opt.Motor ~= 0 and getValue(opt.Motor) > 0
  local rssVal  = (opt["Rx Signal"] ~= 0 and getValue(opt["Rx Signal"])) or 0
  local rqtyVal = (opt["Rx Qty"] ~= 0 and getValue(opt["Rx Qty"])) or 0
  local rpmVal  = (opt.Rpm ~= 0 and getValue(opt.Rpm)) or 0
  
  local thrVal = getValue("Thr") or 0 --throttle telemetry from rotorfligh
  local tbecVal = getValue("Tbec") or 0 --Tbec telemetry from rotorfligh
  local vbecVal = getValue("Vbec") or 0 --Vbec telemetry from rotorfligh

  local ailVal = getValue("ail") or 0
  local eleVal = getValue("ele") or 0
  local colVal = getValue("thr") or 0
  local rudVal = getValue("rud") or 0

  local tescVal = (opt.Tesc ~= 0 and getValue(opt.Tesc)) or 0
  local currVal = (opt.Curr ~= 0 and getValue(opt.Curr)) or 0
  local cellVal = (opt["Rx Cells"] ~= 0 and getValue(opt["Rx Cells"])) or 0
  local rxBattVal  = (opt["Rx Batt"]  ~= 0 and getValue(opt["Rx Batt"]))  or 0
  local rxCellsVal = (opt["Rx Cells"] ~= 0 and getValue(opt["Rx Cells"])) or 0

  -------------------------------------------------------------------------
  -- UPDATE MIN / MAX (only when telemetry valid)
  -------------------------------------------------------------------------

  if rssVal ~= 0 then
    if stats.RSS.min == nil or rssVal < stats.RSS.min then stats.RSS.min = rssVal end
    if stats.RSS.max == nil or rssVal > stats.RSS.max then stats.RSS.max = rssVal end
  end

  if rqtyVal ~= 0 then
    if stats.RQTY.min == nil or rqtyVal < stats.RQTY.min then stats.RQTY.min = rqtyVal end
    if stats.RQTY.max == nil or rqtyVal > stats.RQTY.max then stats.RQTY.max = rqtyVal end
  end

  if rpmVal ~= 0 then
    if stats.RPM.max == nil or rpmVal > stats.RPM.max then stats.RPM.max = rpmVal end
  end

  -------------------------------------------------------------------------
  -- HEADER
  -------------------------------------------------------------------------
local nameColor
if armOn and rssVal ~= 0 then
  nameColor = RED
elseif rssVal ~= 0 then
  nameColor = GREEN
else
  nameColor = WHITE
end

  lcd.drawText(
    z.x + z.w - 55,
    z.y + 6,
    model.getInfo().name or "MODEL",
    RIGHT + DBLSIZE + nameColor
  )

  local dt = getDateTime()
  local months = { "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec" }

  lcd.drawText(z.x + z.w - 10, z.y + 8,
    string.format("%d %s", dt.day, months[dt.mon]),
    RIGHT + SMLSIZE + WHITE)

  lcd.drawText(z.x + z.w - 10, z.y + 22,
    string.format("%02d:%02d", dt.hour, dt.min),
    RIGHT + SMLSIZE + WHITE)

  -------------------------------------------------------------------------
  -- TX BATTERY
  -------------------------------------------------------------------------

  local battX, battY, battW, battH = z.x + 65, z.y + 12, 96, 32
  local txV = getValue("tx-voltage") or 0
  local pct = math.max(0, math.min(1, (txV - 6.8) / (8.4 - 6.8)))

  local battColor = (txV < 7.1) and RED or (txV <= 7.5 and YELLOW or GREEN)

  lcd.drawRectangle(battX, battY, battW, battH, WHITE)
  lcd.drawFilledRectangle(battX + battW, battY + battH / 4, 6, battH / 2, WHITE)
  lcd.drawFilledRectangle(battX + 1, battY + 1, (battW - 2) * pct, battH - 2, battColor)

  lcd.drawText(
    battX + battW / 2,
    battY + battH / 2 - 10,
    string.format("%.1fV", txV),
    CENTER + WHITE + BOLD
  )

  if opt.GV ~= 0 then
    lcd.drawText(
      battX + battW + 30,
      battY + battH / 2 - 15,
      string.format("%d", getValue(opt.GV) or 0),
      LEFT + SMLSIZE + WHITE + BOLD
    )
  end

  local sepY = battY + battH + 6
  lcd.drawFilledRectangle(battX, sepY, z.w - battX - 10, 2, GREY)

-------------------------------------------------------------------------
-- CIRCULAR LAYOUT 
-------------------------------------------------------------------------

local centerY = sepY + 90

local rBig = 83
local rMed = 60

-- BIG CIRCLE (fixed position — adjust this ONLY if you want whole cluster moved)
local rpmCX = z.x + 90   -- all cirlces horizontal position


local columnOffset = rBig + rMed - 30   -- smaller = more overlap with big
local vGap = -35                       --moves smaller circle down/up - down more descreae number

local medCX  = rpmCX + columnOffset
local rqtyCY = centerY + (rMed + vGap)   -- bottom

-- bottom medium
lcd.drawFilledCircle(medCX, rqtyCY, rMed, GREY)
lcd.drawCircle(medCX, rqtyCY, rMed, RED)

-- big (draw first so mediums overlap nicely)
lcd.drawFilledCircle(rpmCX, centerY, rBig, GREY)
lcd.drawCircle(rpmCX, centerY, rBig, RED)

  -------------------------------------------------------------------------
  -- RX BATTERY (VBAT) ABOVE SMALL CIRCLE
  -------------------------------------------------------------------------

  -- Read telemetry
  local vbat = rxBattVal
  local teleCells = rxCellsVal

  local detectedCells
  if teleCells and teleCells >= 3 and teleCells <= 12 then
    detectedCells = teleCells
  end

  local cells = detectedCells or 1
  local vPerCell = (cells > 0 and vbat > 0) and (vbat / cells) or 0


  -------------------------------------------------------------------------
  -- VBAT Voltage → Percentage
  -------------------------------------------------------------------------

  local vMin = 3.3
  local vMax = 4.2

  local vPercent = (vPerCell - vMin) / (vMax - vMin)
  vPercent = math.max(0, math.min(1, vPercent))


  -------------------------------------------------------------------------
  -- VBAT Color + flash logic
  -------------------------------------------------------------------------

  local vColor = GREEN
  local flash = false

  if vPercent <= 0.25 then
    vColor = RED
    flash = true
  elseif vPercent <= 0.50 then
    vColor = YELLOW
  end

  if flash and (getTime() % 20 < 10) then
    vColor = BLACK
  end


  -------------------------------------------------------------------------
  -- VBAT POSITIONING (centered above small circle)
  -------------------------------------------------------------------------

  local battW = rMed + 125
  local battH = 42

  local battX = medCX - battW / 2 + 65
  local battY = rqtyCY - rMed - 38 - 10  -- safely above circle


  -------------------------------------------------------------------------
  -- VBAT DRAW
  -------------------------------------------------------------------------

  drawBatteryIcon(
    battX,
    battY,
    battW,
    battH,
    vPercent,
    vColor
  )

local textX = battX + battW / 2
local textY = battY + 2

lcd.drawText(textX, textY,
  string.format("%.2fV", vbat),
  CENTER + DARKGREY + BOLD)

if detectedCells and vPerCell > 0 then
  lcd.drawText(textX, textY + 14,
    string.format("%.2fV / %dS", vPerCell, detectedCells),
    CENTER + DARKGREY + WHITE)
end

---------------------------------------------------------------------------
-- STICK VALUES (A E C R)
---------------------------------------------------------------------------

local stickX = battX + battW + 18   -- move right of VBAT (adjust spacing here)
local stickY = battY - 3           -- align vertically with battery text
local lineH  = 11                -- spacing between rows

lcd.drawText(stickX, stickY + lineH*0,
  string.format("A: %d", ailVal),
  LEFT + SMLSIZE + ((rssVal ~= 0) and YELLOW or WHITE))

lcd.drawText(stickX, stickY + lineH*1,
  string.format("E: %d", eleVal),
  LEFT + SMLSIZE + ((rssVal ~= 0) and YELLOW or WHITE))

lcd.drawText(stickX, stickY + lineH*2,
  string.format("C: %d", colVal),
  LEFT + SMLSIZE + ((rssVal ~= 0) and YELLOW or WHITE))

lcd.drawText(stickX, stickY + lineH*3,
  string.format("R: %d", rudVal),
  LEFT + SMLSIZE + ((rssVal ~= 0) and YELLOW or WHITE))

---------------------------------------------------------------------------
-- RPM GAUGE (NEEDLE + SCALE + MAX)
---------------------------------------------------------------------------

local rpmMax = 3400
local radius = rBig - 6

-- draw top semicircle arc (ticks + numbers)
local steps = {0,565,1135,1700,2270,2835,3400}

for i = 1, #steps do
  local val = steps[i]

  -- map 0→3400 to 180°→0°
  local angle = math.rad(180 - (val / rpmMax) * 180)

  local tickLen = 6

  local x1 = rpmCX + math.cos(angle) * (radius - tickLen/2)
  local y1 = centerY - math.sin(angle) * (radius - tickLen/2)

  local x2 = rpmCX + math.cos(angle) * (radius + tickLen/2)
  local y2 = centerY - math.sin(angle) * (radius + tickLen/2)


  -- Ticks
  lcd.drawLine(x1, y1, x2, y2, SOLID)


  -- Numbers inside circle
  local tx = rpmCX + math.cos(angle) * (radius - 11)
  local ty = centerY - math.sin(angle) * (radius - 11) - 8

  lcd.drawText(tx, ty, tostring(math.floor(val / 100 + 0.5)), CENTER + SMLSIZE + ((rssVal ~= 0) and YELLOW or WHITE))



end

---------------------------------------------------------------------------
-- RPM NEEDLE
---------------------------------------------------------------------------

-- Curr value drawn before needle
lcd.drawText(rpmCX, centerY - 35,
  string.format("%dA", currVal),
  CENTER + SMLSIZE + BOLD + ((rssVal ~= 0) and YELLOW or WHITE)
)

local rpmClamped = math.max(0, math.min(rpmMax, rpmVal))
local angle = math.rad(180 - (rpmClamped / rpmMax) * 180)

local needleLen = radius - 25

-- floor to integers
local nx = math.floor(rpmCX + math.cos(angle) * needleLen + 0.5)
local ny = math.floor(centerY - math.sin(angle) * needleLen + 0.5)

-- thicker needle
for o = -3, 3 do
  lcd.drawLine(rpmCX + o, centerY, nx + o, ny, SOLID)
end

-- hub
lcd.drawFilledCircle(rpmCX, centerY, 4, BLACK)
lcd.drawFilledCircle(rpmCX, centerY, 2, WHITE)


---------------------------------------------------------------------------
-- RPM TEXT
---------------------------------------------------------------------------

lcd.drawText(rpmCX, centerY + 5,
  string.format("%d", rpmVal),
  CENTER + MIDSIZE + BOLD + ((rssVal ~= 0) and GREEN or WHITE)
)

lcd.drawText(rpmCX, centerY + 40,
  "x100 RPM",
  CENTER + SMLSIZE + WHITE)

--if stats.RPM.max then -- this is the max RPM 
  --lcd.drawText(rpmCX, centerY + 55,
    --string.format("%d", stats.RPM.max),
    --CENTER + SMLSIZE + WHITE)
--end

-- Throttle % drawn after RPM
lcd.drawText(rpmCX, centerY + 55,
  string.format("%d%%", thrVal),
  CENTER + SMLSIZE + ((rssVal ~= 0) and YELLOW or WHITE)
)


   -------------------------------------------------------------------------
  -- ESC TEMP (SPEEDOMETER IN SMALL CIRCLE)
  -------------------------------------------------------------------------

  local tescMin = 0
  local tescMax = 100
  local sweepDeg = 110
  local radius = rMed - 6

  local tescVal = (opt.Tesc ~= 0 and getValue(opt.Tesc)) or 0

  local escColor = WHITE
  if tescVal >= 70 then
    escColor = RED
  elseif tescVal >= 50 then
    escColor = YELLOW
  elseif tescVal > 0 then
    escColor = GREEN
  end


  -------------------------------------------------------------------------
  -- TESC SCALE (ticks + numbers)
  -------------------------------------------------------------------------

  local steps = {0, 25, 50, 75, 100}

  for i = 1, #steps do
    local val = steps[i]

    local pct = val / 100
    local angle = math.rad(0 + pct * sweepDeg)

    local tickLen = 5

    local x1 = medCX + math.cos(angle) * (radius - tickLen/2)
    local y1 = rqtyCY - math.sin(angle) * (radius - tickLen/2)

    local x2 = medCX + math.cos(angle) * (radius + tickLen/2)
    local y2 = rqtyCY - math.sin(angle) * (radius + tickLen/2)

    lcd.drawLine(x1, y1, x2, y2, SOLID)

    -- numbers
    local tx = medCX + math.cos(angle) * (radius - 12)
    local ty = rqtyCY - math.sin(angle) * (radius - 12) - 6

    lcd.drawText(tx, ty, tostring(val), CENTER + SMLSIZE + ((rssVal ~= 0) and YELLOW or WHITE))
  end


  -------------------------------------------------------------------------
  -- TESC NEEDLE
  -------------------------------------------------------------------------

  local tescClamped = math.max(tescMin, math.min(tescMax, tescVal))
  local pct = tescClamped / 100
  local angle = math.rad(0 + pct * sweepDeg)

  local needleLen = radius - 16

  local nx = math.floor(medCX + math.cos(angle) * needleLen + 0.5)
  local ny = math.floor(rqtyCY - math.sin(angle) * needleLen + 0.5)

  for o = -2, 2 do
    lcd.drawLine(medCX + o, rqtyCY, nx + o, ny, SOLID)
  end

  lcd.drawFilledCircle(medCX, rqtyCY, 3, BLACK)
  lcd.drawFilledCircle(medCX, rqtyCY, 1, WHITE)


  -------------------------------------------------------------------------
  -- TESC VALUE + LABEL
  -------------------------------------------------------------------------

  lcd.drawText(
    medCX,
    rqtyCY + 5,
    string.format("%d°C", tescVal),
    CENTER + MIDSIZE + BOLD + escColor
  )

  lcd.drawText(
    medCX,
    rqtyCY + 40,
    sourceLabel(opt.Tesc, "TESC"),
    CENTER + SMLSIZE + WHITE
  )

  -------------------------------------------------------------------------
  -- 1RSS SEGMENTED VERTICAL BAR
  -------------------------------------------------------------------------

  local barW, barH = 24, 90
  local gap = 12

  -- position: right of small circle
  local barX = medCX + rMed + gap
  local barY = rqtyCY - barH / 2 - 15

  lcd.drawRectangle(barX, barY, barW, barH, WHITE)


  -------------------------------------------------------------------------
  -- 1RSS → percentage (0 = full, -100 = empty)
  -------------------------------------------------------------------------

  local rssClamped = math.max(-100, math.min(0, rssVal))
  local pct = 0
  if rssVal ~= 0 then
    pct = 1 - (math.abs(rssClamped) / 100)
  end


  -------------------------------------------------------------------------
  -- 1RSS SEGMENTED FILL (white blocks with divider lines)
  -------------------------------------------------------------------------

  local segments = 8
  local segGap = 2
  local segH = (barH - (segments-1)*segGap) / segments

  local filledSegs = math.floor(pct * segments)

  -- BAR COLOR (segments only)
  local barColor = WHITE
  if rssVal <= -85 then
    barColor = RED
  elseif rssVal <= -70 then
    barColor = YELLOW
  elseif rssVal < 0 then
    barColor = GREEN
  end


  for i = 0, segments-1 do
    local y = barY + barH - (i+1)*segH - i*segGap

    -- filled blocks
    if i < filledSegs then
      lcd.drawFilledRectangle(
        barX + 1,
        y,
        barW - 2,
        segH,
        barColor   
      )
    end

    -- divider line
    if i < segments-1 then
      lcd.drawLine(barX, y - segGap/2, barX + barW, y - segGap/2, GREY)
    end
  end

  -------------------------------------------------------------------------
  -- 1RSS VALUE + LABEL
  -------------------------------------------------------------------------

  lcd.drawText(
    barX + barW/2,
    barY + barH + 4,
    string.format("%ddB", rssVal),
    CENTER + SMLSIZE + WHITE
  )

  lcd.drawText(
    barX + barW/2,
    barY + barH + 18,
    sourceLabel(opt["Rx Signal"], "1RSS"),
    CENTER + SMLSIZE + WHITE
  )

  -------------------------------------------------------------------------
  -- RQLY SEGMENTED VERTICAL BAR
  -------------------------------------------------------------------------

  local barW, barH = 24, 90
  local gap = 12

  -- position: right of RSS bar
  local barX2 = barX + barW + gap
  local barY2 = barY

  lcd.drawRectangle(barX2, barY2, barW, barH, WHITE)


  -------------------------------------------------------------------------
  -- RQLY → percentage (0 = empty, 100 = full)
  -------------------------------------------------------------------------

  local rqtyClamped = math.max(0, math.min(100, rqtyVal))
  local pct = rqtyClamped / 100


  -------------------------------------------------------------------------
  -- RQLY SEGMENTED FILL (same layout as RSS)
  -------------------------------------------------------------------------

  local segments = 8
  local segGap = 2
  local segH = (barH - (segments-1)*segGap) / segments

  local filledSegs = math.floor(pct * segments)

  -- BAR COLOR (your exact logic)
  local rqtyColor = WHITE
  if rqtyVal < 1 then
    rqtyColor = WHITE
  elseif rqtyVal <= 69 then
    rqtyColor = RED
  elseif rqtyVal <= 89 then
    rqtyColor = YELLOW
  elseif rqtyVal <= 100 then
    rqtyColor = GREEN
  end


  for i = 0, segments-1 do
    local y = barY2 + barH - (i+1)*segH - i*segGap

    -- filled blocks
    if i < filledSegs then
      lcd.drawFilledRectangle(
        barX2 + 1,
        y,
        barW - 2,
        segH,
        rqtyColor
      )
    end

    -- divider line
    if i < segments-1 then
      lcd.drawLine(barX2, y - segGap/2, barX2 + barW, y - segGap/2, GREY)
    end
  end

  -------------------------------------------------------------------------
  -- RQLY VALUE + LABEL
  -------------------------------------------------------------------------

  lcd.drawText(
    barX2 + barW/2,
    barY2 + barH + 4,
    string.format("%d%%", rqtyVal),
    CENTER + SMLSIZE + WHITE
  )

  lcd.drawText(
    barX2 + barW/2,
    barY2 + barH + 18,
    sourceLabel(opt["Rx Qty"], "RQly"),
    CENTER + SMLSIZE + WHITE
  )


  -------------------------------------------------------------------------
  -- TBEC SEGMENTED VERTICAL BAR
  -------------------------------------------------------------------------

  local barW, barH = 24, 90
  local gap = 12

  -- position: right of RQly bar
  local barX3 = barX2 + barW + gap
  local barY3 = barY2

  lcd.drawRectangle(barX3, barY3, barW, barH, WHITE)


  -------------------------------------------------------------------------
  -- TBEC → percentage (0 empty, 100 full)
  -------------------------------------------------------------------------

  local tbecClamped = math.max(0, math.min(100, tbecVal))
  local pct = tbecClamped / 100


  -------------------------------------------------------------------------
  -- TBEC COLOR (temperature rules)
  -------------------------------------------------------------------------

  local tbecColor = GREEN
  if tbecVal > 70 then
    tbecColor = RED
  elseif tbecVal > 50 then
    tbecColor = YELLOW
  end


  -------------------------------------------------------------------------
  -- TBEC SEGMENTED FILL (same style as others)
  -------------------------------------------------------------------------

  local segments = 8
  local segGap = 2
  local segH = (barH - (segments-1)*segGap) / segments

  local filledSegs = math.floor(pct * segments)

  for i = 0, segments-1 do
    local y = barY3 + barH - (i+1)*segH - i*segGap

    if i < filledSegs then
      lcd.drawFilledRectangle(
        barX3 + 1,
        y,
        barW - 2,
        segH,
        tbecColor
      )
    end

    if i < segments-1 then
      lcd.drawLine(barX3, y - segGap/2, barX3 + barW, y - segGap/2, GREY)
    end
  end


  -------------------------------------------------------------------------
  -- TBEC VALUE + LABEL
  -------------------------------------------------------------------------

  lcd.drawText(
    barX3 + barW/2,
    barY3 + barH + 4,
    string.format("%d°C", tbecVal),
    CENTER + SMLSIZE + WHITE
  )

  lcd.drawText(
    barX3 + barW/2,
    barY3 + barH + 18,
    "TBEC",
    CENTER + SMLSIZE + WHITE
  )


  -------------------------------------------------------------------------
  -- VBEC SEGMENTED VERTICAL BAR
  -------------------------------------------------------------------------

  local barW, barH = 24, 90
  local gap = 12

  -- position: right of TBEC bar
  local barX4 = barX3 + barW + gap
  local barY4 = barY3

  lcd.drawRectangle(barX4, barY4, barW, barH, WHITE)


  -------------------------------------------------------------------------
  -- VBEC → percentage (0 empty, 9V full)
  -------------------------------------------------------------------------

  local vbecClamped = math.max(0, math.min(9, vbecVal))
  local pct = vbecClamped / 9


  -------------------------------------------------------------------------
  -- VBEC COLOR (voltage rules)
  -------------------------------------------------------------------------

  local vbecColor = GREEN
  if vbecVal < 6.0 then
    vbecColor = RED
  elseif vbecVal < 6.5 then
    vbecColor = YELLOW
  end


  -------------------------------------------------------------------------
  --VBEC SEGMENTED FILL (same style as others)
  -------------------------------------------------------------------------

  local segments = 8
  local segGap = 2
  local segH = (barH - (segments-1)*segGap) / segments

  local filledSegs = math.floor(pct * segments)

  for i = 0, segments-1 do
    local y = barY4 + barH - (i+1)*segH - i*segGap

    if i < filledSegs then
      lcd.drawFilledRectangle(
        barX4 + 1,
        y,
        barW - 2,
        segH,
        vbecColor
      )
    end

    if i < segments-1 then
      lcd.drawLine(barX4, y - segGap/2, barX4 + barW, y - segGap/2, GREY)
    end
  end


  -------------------------------------------------------------------------
  --VBEC VALUE + LABEL
  -------------------------------------------------------------------------

  lcd.drawText(
    barX4 + barW/2,
    barY4 + barH + 4,
    string.format("%.1fV", vbecVal),
    CENTER + SMLSIZE + WHITE
  )

  lcd.drawText(
    barX4 + barW/2,
    barY4 + barH + 18,
    "VBEC",
    CENTER + SMLSIZE + WHITE
  )


 ---------------------------------------------------------------------------
 -- TIMER (VARIABLES)
 ---------------------------------------------------------------------------

 local timer = model.getTimer(0)
 local timeLeft = timer.value or 0
 local maxTime  = timer.start or 1
 local tPct = math.max(0, math.min(1, timeLeft / maxTime))

 -------------------------------------------------------------------------
 -- VERTICAL TIMER BAR
 -------------------------------------------------------------------------

  local barW, barH = 24, 90
  local barX = z.x + z.w - barW - 30
  local barY = centerY - barH / 2 + 10

  lcd.drawRectangle(barX, barY, barW, barH, WHITE)

  if rssVal ~= 0 then
    local barColor =
      (tPct <= 0.15) and RED or
      (tPct <= 0.50) and YELLOW or GREEN

    local fillH = math.floor(barH * tPct)
    lcd.drawFilledRectangle(
      barX + 1,
      barY + barH - fillH + 1,
      barW - 2,
      fillH - 2,
      barColor
    )
  end

  lcd.drawText(
    barX + barW / 2,
    barY + barH + 4,
    string.format("%02d:%02d", math.floor(timeLeft / 60), timeLeft % 60),
    CENTER + SMLSIZE + WHITE
  )

---------------------------------------------------------------------------
-- STATUS TILES
---------------------------------------------------------------------------

-- Anchor status tiles below the timer
local tileThirdY = z.y + z.h - 40
local bottomTileH = 36
local statusTileH = math.floor(bottomTileH * 0.90)
local statusTextY = tileThirdY + statusTileH / 2 - 20

local motorOn = opt.Motor ~= 0 and getValue(opt.Motor) > 0
local fm      = getFlightMode() or 0

local texts = {
  motorOn and "Motor On" or "Motor Off",
  armOn and "ARMED" or "DISARMED",
  "FM" .. fm
}

-- ORIGINAL WIDTH LOGIC (middle tile wider)
local margin = 10
local gap = 8
local usableW = z.w - margin * 2 - gap * 2

local widths = {
  math.floor(usableW / 3),
  math.floor((usableW / 3) * 1.4),
}
widths[3] = usableW - widths[1] - widths[2]

local x = z.x + margin

for i = 1, 3 do
  local rssVal = (opt["Rx Signal"] ~= 0 and getValue(opt["Rx Signal"])) or 0

  if (i == 1 and motorOn and rssVal ~= 0)
     or (i == 2 and armOn and rssVal ~= 0) then
    lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, RED)

  elseif (i == 1 and rssVal ~= 0)
      or (i == 2 and rssVal ~= 0) then
    lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, GREEN)

  elseif i == 3 and rssVal ~= 0 and armOn then
    lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, RED)

  elseif i == 3 and rssVal ~= 0 then
    lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, GREEN)
  end

  lcd.drawRectangle(x, tileThirdY, widths[i], statusTileH, GREY)

  lcd.drawText(
    x + widths[i] / 2,
    statusTextY,
    texts[i],
    CENTER + DBLSIZE + WHITE
  )

  x = x + widths[i] + gap
end

end

---------------------------------------------------------------------------

return {
  name = name,
  create = create,
  refresh = refresh,
  update = update,
  options = options
}
